var searchData=
[
  ['heap_20allocation_10',['Heap Allocation',['../group__heap.html',1,'']]],
  ['heap_20introspection_11',['Heap Introspection',['../group__analysis.html',1,'']]]
];
