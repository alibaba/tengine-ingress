#!/bin/bash

brew update
brew install bazel
