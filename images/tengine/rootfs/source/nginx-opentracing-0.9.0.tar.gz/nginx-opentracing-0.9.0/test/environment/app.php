<?php
assert(isset($_SERVER["HTTP_X_OT_SPAN_CONTEXT"]));
?>
