/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQUIC_XQC_H3_TEST_H
#define XQUIC_XQC_H3_TEST_H

void xqc_test_frame();
void xqc_test_stream();
void xqc_test_ins();
void xqc_test_rep();

#endif //XQUIC_XQC_H3_TEST_H
