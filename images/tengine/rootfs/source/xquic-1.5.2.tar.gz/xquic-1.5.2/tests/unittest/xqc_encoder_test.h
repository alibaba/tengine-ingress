/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_ENCODER_TEST_H
#define XQC_ENCODER_TEST_H

void xqc_test_encoder();

#endif
