/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_RETRY_TEST_H
#define XQC_RETRY_TEST_H

void xqc_test_retry();

#endif
