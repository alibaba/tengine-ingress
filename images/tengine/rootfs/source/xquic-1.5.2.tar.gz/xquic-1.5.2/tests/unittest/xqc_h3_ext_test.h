/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQUIC_XQC_H3_EXT_TEST_H
#define XQUIC_XQC_H3_EXT_TEST_H

void xqc_test_h3_ext_frame();

#endif //XQUIC_XQC_H3_EXT_TEST_H
