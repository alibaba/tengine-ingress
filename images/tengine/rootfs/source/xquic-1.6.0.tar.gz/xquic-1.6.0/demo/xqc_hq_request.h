/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_HQ_REQUEST_H
#define XQC_HQ_REQUEST_H

#include "xqc_hq.h"

extern const xqc_stream_callbacks_t hq_stream_callbacks;

#endif