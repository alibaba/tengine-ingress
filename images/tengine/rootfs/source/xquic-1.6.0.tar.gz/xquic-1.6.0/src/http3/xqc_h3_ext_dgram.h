/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef _XQC_H3_EXT_DGRAM_H_INCLUDED_
#define _XQC_H3_EXT_DGRAM_H_INCLUDED_

#include <xquic/xquic.h>

extern const xqc_datagram_callbacks_t h3_ext_datagram_callbacks;

#endif