/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_PQ_TEST_H
#define XQC_PQ_TEST_H

#include "src/common/xqc_priority_q.h"

void xqc_test_pq();

#endif
