/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_RING_ARRAY_TEST_H
#define XQC_RING_ARRAY_TEST_H


void test_ring_array();

#endif
