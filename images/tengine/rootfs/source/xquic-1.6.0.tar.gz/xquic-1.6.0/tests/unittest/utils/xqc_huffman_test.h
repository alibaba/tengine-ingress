/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_HUFFMAN_TEST_H
#define XQC_HUFFMAN_TEST_H

void xqc_test_huffman();

#endif
