/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_2D_HASH_TABLE_TEST_H
#define XQC_2D_HASH_TABLE_TEST_H

void test_2d_hash_table();


#endif
