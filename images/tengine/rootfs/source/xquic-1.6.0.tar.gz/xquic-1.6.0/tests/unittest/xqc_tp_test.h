/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef _XQC_TP_TEST_H_
#define _XQC_TP_TEST_H_

void xqc_test_transport_params();

#endif
