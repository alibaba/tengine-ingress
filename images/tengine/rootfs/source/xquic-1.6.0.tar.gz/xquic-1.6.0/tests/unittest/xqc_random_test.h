/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_RANDOM_TEST_H
#define XQC_RANDOM_TEST_H

#include "src/common/xqc_random.h"
#include "src/common/xqc_common.h"

void xqc_test_get_random();

#endif