/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef _XQC_DATAGRAM_TEST_H_INCLUDED_
#define _XQC_DATAGRAM_TEST_H_INCLUDED_

void xqc_test_receive_invalid_dgram();

#endif /* _XQC_CUBIC_TEST_H_INCLUDED_ */
