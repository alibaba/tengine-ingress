
//line x4.go:4
package main
func F4() {}
